using UnityEngine;
public class Rito_Cura : Ataque
{
    [Header("Rito de Cura")]

    public float tamanhoBase = 3f;
    public float duracao = 5f;
    public float intervaloCura = 1f;
    public float curaPorTick = 10f;

    private float _timerDuracao;
    private float _timerTick;

    private Animator _animator;
    private CircleCollider2D _collider;

    protected override void Awake()
    {
        base.Awake();

        _animator = GetComponent<Animator>();
        _collider = GetComponent<CircleCollider2D>();
    }

    public override void Ativar()
    {
        base.Ativar();

        transform.position = _dono.transform.position;

        ConfigurarEscalaVisual();

        _timerDuracao = duracao;
        _timerTick = intervaloCura;

        StartCoroutine(RotinaRito());
    }

    private void ConfigurarEscalaVisual()
    {
        float forca = Mathf.Clamp01(_nivelPoder / 10f);

        _animator.SetFloat("forca", forca);

        float escalaFinal = tamanhoBase * (1 + forca);
        transform.localScale = Vector3.one * escalaFinal;

        _collider.radius = escalaFinal;
    }

    private IEnumerator RotinaRito()
    {
        float tempoRestante = duracao;

        while (tempoRestante > 0)
        {
            tempoRestante -= intervaloCura;

            yield return new WaitForSeconds(intervaloCura);
        }

        Desativar();
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (!other.TryGetComponent(out Ser_Vivo alvo)) return;

        if (alvo != _dono) return;

        _timerTick -= Time.deltaTime;

        if (_timerTick <= 0)
        {
            alvo.Curar(curaPorTick);
            _timerTick = intervaloCura;
        }
    }

    protected override void Desativar()
    {
        base.Desativar();
        Destroy(gameObject);
    }
}