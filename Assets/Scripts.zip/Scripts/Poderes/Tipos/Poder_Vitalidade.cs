using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Poder_Vitalidade : Poder
{
    public float _acrescimoVidaMax;
    public float _valorCura;
    public float _intervaloCura;
    public float _rouboVida;
    public bool _estaRegenerando;
}
