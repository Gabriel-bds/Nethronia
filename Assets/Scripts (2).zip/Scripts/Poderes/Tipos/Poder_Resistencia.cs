using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
[System.Serializable]
public class Poder_Resistencia : Poder
{
    public float _negacaoDano;
    public float _negacaoRepulsao;
}
