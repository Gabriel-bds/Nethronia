using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConjuntoSonoroVolumeProgressivo : ConjuntoSonoro
{
    public Tipo_Poder tipoPoderParaEscala;
    public int nivelMaximo;
    public float volumeMinimo;
    public float volumeMaximo;
}
