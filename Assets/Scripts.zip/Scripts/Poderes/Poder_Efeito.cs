using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Poder_Efeito : Poder_Ofensivo
{
    public Status _status;
}
